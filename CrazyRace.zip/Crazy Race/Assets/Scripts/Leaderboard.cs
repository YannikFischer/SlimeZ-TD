using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using TMPro;
using System.Xml.Serialization;
using UnityEngine.UI;
using System.IO;

public class Leaderboard : MonoBehaviour
{
    static GameObject inputfield;
    static GameObject NextButton;
    static GameObject FinishLeaderboard;
    static GameObject LeaderboardText;
    static GameObject BackToTrackSelectionButton;
    static GameObject NameFieldEmptyImage;

    // Start is called before the first frame update
    void Start()
    {
        inputfield = GameObject.Find("NameInputField");
        NextButton = GameObject.Find("NextButton");
        FinishLeaderboard = GameObject.Find("Leaderboard");
        LeaderboardText = GameObject.Find("LeaderboardText");
        BackToTrackSelectionButton = GameObject.Find("BackToTrackSelectionButton");
        NameFieldEmptyImage = GameObject.Find("NameFieldEmptyImage");

        FinishLeaderboard.SetActive(false);
        LeaderboardText.SetActive(false);
        BackToTrackSelectionButton.SetActive(false);
        NameFieldEmptyImage.SetActive(false);
    }

    public static void Save()
    {
        if (inputfield.GetComponent<TMP_InputField>().text != "")
        {
            NameFieldEmptyImage.SetActive(false);

            string folderpath = @"Bestzeiten";
            string filestreampath = "";
            string inputtext = inputfield.GetComponent<TMP_InputField>().text;
            int iVerschl�sselungsVerschiebung = 5;

            List<CLeaderboardRow> My_CLeaderboardRows = new List<CLeaderboardRow>();
            CLeaderboardRow My_CLeaderboardRow = new CLeaderboardRow(Leaderboard.Ver_Entschl�sselung(inputtext, iVerschl�sselungsVerschiebung), Leaderboard.Ver_Entschl�sselung(InGameUI.finaltime, iVerschl�sselungsVerschiebung));

            if (!File.Exists(folderpath))
            {
                Directory.CreateDirectory(folderpath);
            }

            if (SceneLoader.OesterreichGP == true)
            {
                filestreampath = @"Bestzeiten\OesterreichGP.xml";
                Debug.Log("O");
            }
            else if (SceneLoader.SchweizGP == true)
            {
                filestreampath = @"Bestzeiten\SchweizGP.xml";
                Debug.Log("S");
            }
            else if (SceneLoader.DeutschlandGP == true)
            {
                filestreampath = @"Bestzeiten\DeutschlandGP.xml";
                Debug.Log("D");
            }

            XmlSerializer My_XMLSerializer = new XmlSerializer(typeof(List<CLeaderboardRow>));

            if (File.Exists(filestreampath))
            {
                FileStream My_Filestream = new FileStream(filestreampath, FileMode.Open);
                My_CLeaderboardRows = (List<CLeaderboardRow>)My_XMLSerializer.Deserialize(My_Filestream);

                for (int i = 0; i < My_CLeaderboardRows.Count; i++)
                {
                    if (My_CLeaderboardRow.PlayerName == My_CLeaderboardRows[i].PlayerName && string.Compare(My_CLeaderboardRow.time, My_CLeaderboardRows[i].time) == -1)
                    {
                        My_CLeaderboardRows.RemoveAt(i);
                        My_CLeaderboardRows.Add(My_CLeaderboardRow);
                        Debug.Log("Bessere Zeit");
                    }
                    else if (My_CLeaderboardRow.PlayerName != My_CLeaderboardRows[i].PlayerName)
                    {
                        if (My_CLeaderboardRows.Count >= 10)
                        {
                            if (string.Compare(My_CLeaderboardRow.time, My_CLeaderboardRows[9].time) == -1)
                            {
                                My_CLeaderboardRows.RemoveAt(9);
                                My_CLeaderboardRows.Add(My_CLeaderboardRow);
                                Debug.Log("Neu und besser als der Zehnte");
                            }
                        }
                        else
                        {
                            My_CLeaderboardRows.Add(My_CLeaderboardRow);
                            Debug.Log("Zeit ist egal es gibt noch keine Top 10");
                        }
                    }
                    break;
                }

                My_Filestream.Close();

                FileStream My_Filestream1 = new FileStream(filestreampath, FileMode.Truncate);
                My_Filestream1.Close();
            }
            else
            {
                My_CLeaderboardRows.Add(My_CLeaderboardRow);
                Debug.Log("Dokument existierte noch nicht");
            }

            My_CLeaderboardRows.Sort((p1, p2) => { return p1.time.CompareTo(p2.time); });

            FileStream My_Filestream2 = new FileStream(filestreampath, FileMode.Append, FileAccess.Write);
            My_XMLSerializer.Serialize(My_Filestream2, My_CLeaderboardRows);
            My_Filestream2.Close();

            inputfield.SetActive(false);
            NextButton.SetActive(false);
            FinishLeaderboard.SetActive(true);
            LeaderboardText.SetActive(true);
            BackToTrackSelectionButton.SetActive(true);

            FileStream My_Filestream3 = new FileStream(filestreampath, FileMode.Open);
            List<CLeaderboardRow> My_CLeaderboardRows1 = (List<CLeaderboardRow>)My_XMLSerializer.Deserialize(My_Filestream3);
            My_Filestream3.Close();

            bool first = true;

            for (int i = 0; i < My_CLeaderboardRows1.Count; i++)
            {
                if (first == true)
                {
                    FinishLeaderboard.transform.Find("Content/Names").GetComponent<TMP_Text>().text += Ver_Entschl�sselung(My_CLeaderboardRows1[i].PlayerName, -iVerschl�sselungsVerschiebung);
                    FinishLeaderboard.transform.Find("Content/Times").GetComponent<TMP_Text>().text += Ver_Entschl�sselung(My_CLeaderboardRows1[i].time, -iVerschl�sselungsVerschiebung);
                    first = false;
                }
                else
                {
                    FinishLeaderboard.transform.Find("Content/Names").GetComponent<TMP_Text>().text += "\n" + Ver_Entschl�sselung(My_CLeaderboardRows1[i].PlayerName, -iVerschl�sselungsVerschiebung);
                    FinishLeaderboard.transform.Find("Content/Times").GetComponent<TMP_Text>().text += "\n" + Ver_Entschl�sselung(My_CLeaderboardRows1[i].time, -iVerschl�sselungsVerschiebung);
                }
            }
        }
        else
        {
            NameFieldEmptyImage.SetActive(true);
        }
    }

    private static string Ver_Entschl�sselung(string zuver_entschl�sseln, int iVerschiebung)
    {
        string strStringVer_Entschl�sselt = "";

        foreach (char c in zuver_entschl�sseln)
        {
            char x = (char)(c + iVerschiebung);
            strStringVer_Entschl�sselt += x.ToString();
        }

        return strStringVer_Entschl�sselt;
    }
}

[Serializable()]
public class CLeaderboardRow
{
    private String _PlayerName;

    public String PlayerName
    {
        get { return _PlayerName; }
        set { _PlayerName = value; }
    }


    private String _time;

    public String time
    {
        get { return _time; }
        set { _time = value; }
    }


    public CLeaderboardRow()
    {
        this._PlayerName = "";
        this._time = "";
    }


    public CLeaderboardRow(string PlayerNameK, String timeK)
    {
        this._PlayerName = PlayerNameK;
        this._time = timeK;
    }
}