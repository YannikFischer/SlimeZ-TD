using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class InGameUI : MonoBehaviour
{
    public TMP_Text StartCountdownText;
    public TMP_Text CurrentLapText;
    public TMP_Text LapTimeText;
    public TMP_Text FalseDirectionText;

    float time;
    int milliseconds;
    int seconds;
    int minutes;

    string millisecondsshowed;
    string secondsshowed;
    string minutesshowed;

    public static bool StartCountdownFinished = false;
    public static string finaltime;

    // Start is called before the first frame update
    void Start()
    {
        StartCountdownFinished = false;
        FalseDirectionText.gameObject.SetActive(false);
        StartCoroutine("Countdown");
    }

    // Update is called once per frame
    void Update()
    {
        if (TrackObjectives.lapcount > 0)
        {
            CurrentLapText.text = TrackObjectives.lapcount + "/3";
        }


        if (TrackObjectives.falsedirection == true)
        {
            FalseDirectionText.gameObject.SetActive(true);
        }
        else
        {
            FalseDirectionText.gameObject.SetActive(false); ;
        }


        if (StartCountdownFinished == true)
        {
            time += Time.deltaTime * 1000;
            milliseconds = Convert.ToInt32(Math.Round((time % 1000) / 10));
            seconds = (Convert.ToInt32(time) / 1000) % 60;
            minutes = (Convert.ToInt32(time) / 1000) / 60;

            if (milliseconds < 10)
            {
                millisecondsshowed = "0" + milliseconds;
            }
            else
            {
                millisecondsshowed = Convert.ToString(milliseconds);
            }

            if (seconds < 10)
            {
                secondsshowed = "0" + seconds;
            }
            else
            {
                secondsshowed = Convert.ToString(seconds);
            }

            if (minutes < 10)
            {
                minutesshowed = "0" + minutes;
            }
            else
            {
                minutesshowed = Convert.ToString(minutes);
            }

            LapTimeText.text = minutesshowed + ":" + secondsshowed + ":" + millisecondsshowed;

            if (TrackObjectives.lapcount > 2)
            {
                finaltime = LapTimeText.text;
            }
        }
    }

    IEnumerator Countdown()
    {
        yield return new WaitForSeconds(1f);
        StartCountdownText.text = "2";
        yield return new WaitForSeconds(1f);
        StartCountdownText.text = "1";
        yield return new WaitForSeconds(1f);
        StartCountdownText.gameObject.SetActive(false);
        StartCountdownFinished = true;
    }
}