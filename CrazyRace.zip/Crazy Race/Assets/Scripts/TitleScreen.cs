using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TitleScreen : MonoBehaviour
{
    public GameObject BlinkingText;

    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine("DelayAction");
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Return))
        {
            SceneLoader.LoadScene("TrackSelectionScreen");
        }
    }

    IEnumerator DelayAction()
    {
        while(true)
        {
            yield return new WaitForSeconds(.6f);
            BlinkingText.SetActive(false);
            yield return new WaitForSeconds(.6f);
            BlinkingText.SetActive(true);
        }
    }
}