using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneLoader : MonoBehaviour
{
    public static bool OesterreichGP;
    public static bool SchweizGP;
    public static bool DeutschlandGP;

    public static void LoadScene(string Scene)
    {
        switch (Scene)
        {
            case "Oesterreich GP":
                OesterreichGP = true;
                SchweizGP = false;
                DeutschlandGP = false;
                break;
            case "Schweiz GP":
                OesterreichGP = false;
                SchweizGP = true;
                DeutschlandGP = false;
                Debug.Log(SchweizGP);
                break;
            case "Deutschland GP":
                OesterreichGP = false;
                SchweizGP = false;
                DeutschlandGP = true;
                break;
        }

        SceneManager.LoadSceneAsync(Scene);
    }
}