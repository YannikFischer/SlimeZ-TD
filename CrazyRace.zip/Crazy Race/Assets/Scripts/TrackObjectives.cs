using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrackObjectives : MonoBehaviour
{
    bool StartControl = false;
    bool Control1 = false;
    bool Control2 = false;
    bool Control3 = true;

    public static int lapcount;
    public static bool falsedirection;

    // Start is called before the first frame update
    void Start()
    {
        lapcount = 0;
        falsedirection = false;
    }

    public void OnTriggerEnter(Collider collider)
    {
        if (Control3 == true && collider.tag == "StartControl")
        {
            StartControl = true;
            Control3 = false;
            falsedirection = false;

            if (lapcount > 2)
            {
                SceneLoader.LoadScene("FinishLeaderboard");
            }
            else
            {
                lapcount += 1;
            }
        }
        else if (StartControl == true && collider.tag == "Control 1")
        {
            Control1 = true;
            StartControl = false;
            falsedirection = false;
        }
        else if (Control1 == true && collider.tag == "Control 2")
        {
            Control2 = true;
            Control1 = false;
            falsedirection = false;
        }
        else if (Control2 == true && collider.tag == "Control 3")
        {
            Control3 = true;
            Control2 = false;
            falsedirection = false;
        }
        else
        {
            falsedirection = true;
        }
    }
}