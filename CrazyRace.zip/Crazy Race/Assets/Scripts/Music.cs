using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Music : MonoBehaviour
{
   void Awake()
   {
        GameObject[] MenuAudioSources = GameObject.FindGameObjectsWithTag("MenuMusic");
        GameObject[] InGameAudioSources = GameObject.FindGameObjectsWithTag("InGameMusic");

        if (MenuAudioSources.Length > 1)
        {
            Destroy(this.gameObject);
        }
        else if (InGameAudioSources.Length > 0)
        {
            foreach (GameObject MenuAudioSource in MenuAudioSources)
            {
                Destroy(MenuAudioSource);
            }
        }
        else
        {
            DontDestroyOnLoad(this.gameObject);
        }
    }
}