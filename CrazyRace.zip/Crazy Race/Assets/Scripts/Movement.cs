using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public GameObject SteeringWheel;
    public GameObject WheelFrontLeft;
    public GameObject WheelFrontRight;

    string RestartScene;

    float moveHorizontal;
    float moveVertical;

    bool SteerRight;
    bool SteerLeft;
    string direction;

    float speed;
    float minspeed = -10f;
    float maxspeed = 20f;
    float acceleration = 0.2f;

    bool IsGrounded;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.R))
        {
            if (SceneLoader.OesterreichGP == true)
            {
                RestartScene = "Oesterreich GP";
            }
            else if (SceneLoader.SchweizGP == true)
            {
                RestartScene = "Schweiz GP";
            }
            else if (SceneLoader.DeutschlandGP == true)
            {
                RestartScene = "Deutschland GP";
            }

            SceneLoader.LoadScene(RestartScene);
        }


        if(InGameUI.StartCountdownFinished == true)
        {
            moveVertical = Input.GetAxis("Vertical");
        }

        moveHorizontal = Input.GetAxis("Horizontal");

        if (moveHorizontal > 0 && SteerRight == false)
        {
            WheelFrontLeft.transform.Rotate(0, 20, 0);
            WheelFrontRight.transform.Rotate(0, 20, 0);
            SteeringWheel.transform.Rotate(-20, 0, 0);
            SteerRight = true;
        }
        else if (moveHorizontal < 0 && SteerLeft == false)
        {
            WheelFrontLeft.transform.Rotate(0, -20, 0);
            WheelFrontRight.transform.Rotate(0, -20, 0);
            SteeringWheel.transform.Rotate(20, 0, 0);
            SteerLeft = true;
        }
        else if (moveHorizontal == 0)
        {
            if (SteerRight == true)
            {
                WheelFrontLeft.transform.Rotate(0, -20, 0);
                WheelFrontRight.transform.Rotate(0, -20, 0);
                SteeringWheel.transform.Rotate(20, 0, 0);
                SteerRight = false;
            }
            else if (SteerLeft == true)
            {
                WheelFrontLeft.transform.Rotate(0, 20, 0);
                WheelFrontRight.transform.Rotate(0, 20, 0);
                SteeringWheel.transform.Rotate(-20, 0, 0);
                SteerLeft = false;
            }
        }
    }

    void FixedUpdate()
    {
        if (speed > maxspeed)
        {
            speed = maxspeed;
        }
        else if (speed < minspeed)
        {
            speed = minspeed;
        }


        if (moveVertical <= 0)
        {
            if (moveVertical < 0)
            {
                speed -= acceleration;
                direction = "backwards";
            }
            else
            {
                if (direction == "forwards")
                {
                    speed -= acceleration;

                    if (speed < 0)
                    {
                        speed = 0;
                    }
                }
                else if (direction == "backwards")
                {
                    speed += acceleration;

                    if (speed > 0)
                    {
                        speed = 0;
                    }
                }
            }
        }
        else
        {
            speed += acceleration;
            direction = "forwards";
        }


        if (IsGrounded == true)
        {
            transform.Translate(0, 0, speed * Time.deltaTime);

            if (speed != 0)
            {
                transform.Rotate(0, speed / 20 * moveHorizontal * 150 * Time.deltaTime, 0);
            }
        }
    }

    void OnCollisionStay()
    {
        IsGrounded = true;
        //Debug.Log("IsGrounded");
    }

    void OnCollisionExit()
    {
        IsGrounded = false;
        //Debug.Log("IsNotGrounded");
    }
}